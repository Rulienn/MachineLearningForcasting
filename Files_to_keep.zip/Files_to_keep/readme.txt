Hey ! 
I send you all my useful python files to create the report
Here is the description of each file
"Data_analysis" : contains some graphs and description about the data set. Explain why I choosed some features
"predict_receivals_with_order" : A bad model that tried to predict deliveries with the orders (It have really bad result but it is another kind of model)
"TS_SARIMAX": It is the python file that contain the best SARIMAX I found, it predict net_weight separately for each rm_id
"SARIMA_s7_csv" : It is the associated submission
"XGB_lags_analysis" :  In this file I found correlations between past values (lags) and the current value "net_weight" to create features
"XGBoosts_Find_parameters": It contains a loop on several XGB model with different hyperparameters to find the best XGBoosts_Find_parameters
"XGBoost_best": It is the best model I found, and it give the best submission
"XGBoost_3000-0.02-0.8.csv": It is the associated submission
"short_notebook_1" and "short_notebook_2" contain only necessary python cells to generate the submission



////!!!!\\\\ Required environnement
- install the required importations (First python cell of each file)
- In the folder "APPEND_CONSULTING_PROJECT" with all data :
1) Create a folder "Model" in "APPEND_CONSULTING_PROJECT" and put the models inside
2) Create a folder "Submissions" in "APPEND_CONSULTING_PROJECT", the submission will be generated inside